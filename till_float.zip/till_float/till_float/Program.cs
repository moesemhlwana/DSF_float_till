﻿using System.Text;


int tillStarts = 500, tillTotal= 500;
int total = 0;

// output file is stored on the bin folder
string filePath = Path.Combine(Directory.GetCurrentDirectory(), "output.txt");
 File.WriteAllText(filePath, "Till Start, Transaction Total, Paid, Change Total, Change Breakdown");


foreach (var line in File.ReadLines(@Path.Combine(Directory.GetCurrentDirectory(), "input.txt"), Encoding.UTF8)) {
    // is file is stored on the bin folder. used this method so that you don't have to change directory when run in another pc
    int pos = line.IndexOf(",");
    string items = line.Substring(0, pos) + ";";
    string itemsAmount = line.Remove(0, pos + 1);
    int amountDue = 0;
    int amountPaid = 0;
    int change = 0, y = 0;
    string changeBreakdown = "";

    while (items.IndexOf(";") > 0)
    {
        pos = items.IndexOf(";");
        string item = items.Substring(0, pos);
        amountDue += Convert.ToInt32(item.Remove(0, items.IndexOf("R") + 1));
        items = items.Remove(0, pos + 1);
    }
    itemsAmount += "-";
    while (itemsAmount.IndexOf("-") > 0)
    {
        pos = itemsAmount.IndexOf("-");
        amountPaid += Convert.ToInt32(itemsAmount.Substring(1, pos - 1));
        itemsAmount = itemsAmount.Remove(0, pos + 1);
    }
    change = amountPaid - amountDue;
    y = change;
    tillTotal = tillTotal + amountPaid - change;
    for (int i = 0; y > 0; i++)
    {
        if (y >= 50)
        {
            changeBreakdown += "R50-";
            y -= 50;
        }
        else if (y >= 20)
        {
            changeBreakdown += "R20-";
            y -= 20;
        }
        else if (y >= 10)
        {
            changeBreakdown += "R10-";
            y -= 10;
        }
        else if (y >= 5)
        {
            changeBreakdown += "R5-";
            y -= 5;
        }
        else if (y >= 2)
        {
            changeBreakdown += "R2-";
            y -= 2;
        }
        else if (y >= 1)
        {
            changeBreakdown += "R1-";
            y -= 1;
        }
    }
    pos = changeBreakdown.LastIndexOf("-");
    changeBreakdown = pos > 0 ? changeBreakdown.Substring(0, pos) : "";
    File.AppendAllText(filePath, "\nR" + tillStarts.ToString() + ", R" + amountDue.ToString() + ", R" + amountPaid.ToString() + ", R" + change.ToString() + ", " + changeBreakdown);
    tillStarts += amountDue;
    total += amountDue;
   
}
File.AppendAllText(filePath, "\nR" + tillTotal.ToString());
